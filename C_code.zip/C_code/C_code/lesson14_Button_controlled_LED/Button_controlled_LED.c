#include <wiringPi.h>
#include <stdio.h>
#define btnPin 1  // button Pin BCM GPIO 18
#define ledPin 2  // LED pin BCM GPIO 27
  
int main()
{
  wiringPiSetup();
  int val; //Button variables
  int count = 0; //Record the number of button presses
  int flag = 0;  //Odd even variable
  pinMode(btnPin,INPUT);
  pinMode(ledPin,OUTPUT);
  digitalWrite(ledPin,LOW);  //turn off led
  
  while(1)
  { 
    val=digitalRead(btnPin);  //Receive button value
    if(val == 0)
    {
      delay(10);
      val=digitalRead(btnPin);  //Receive button value
      if(val == 1)
      {
        count = count + 1;
        printf("count = %d",count);
      }
    }
    flag = count % 2; //Remainder 2 ,Even is 0, odd is 1
    if(flag == 1)
      digitalWrite(ledPin,HIGH);  //turn on led
    else
      digitalWrite(ledPin,LOW);  //turn off led
  }	 
}
