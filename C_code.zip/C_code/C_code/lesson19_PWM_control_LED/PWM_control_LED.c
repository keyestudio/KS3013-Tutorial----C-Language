#include <wiringPi.h>
#include <pcf8591.h>  //pcf8591 library
#include <stdio.h>

#define Address 0x48  //iic address
#define BASE 64  //DAC write address
#define A0 BASE+0  //A0 analogRead  address
#define A1 BASE+1  //A1 analogRead  address
#define A2 BASE+2 
#define A3 BASE+3

int main(void)
{
      unsigned char value;
      wiringPiSetup();
      pcf8591Setup(BASE,Address);   //Initialize the pcf8591
        
     while(1)
     {
        value=analogRead(A0);    //read the ADC value of channel 0           
        printf("A0:%d\n",value);
        analogWrite(BASE,value);      //write the DAC value
        printf("AOUT:%d\n",value);
        delay(100);
     }
}
