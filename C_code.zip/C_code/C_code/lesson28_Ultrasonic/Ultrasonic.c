#include <wiringPi.h>
#include <stdio.h>
#include <sys/time.h>   //Import the time system header file

//define the pin
#define Trig    4   //BCM GPIO 23
#define Echo    5   //BCM GPIO 24

//set pin mode
void ultraInit(void)
{
	pinMode(Echo, INPUT);
	pinMode(Trig, OUTPUT);
}

//Write programs based on sequence diagrams
float disMeasure(void)
{
	struct timeval tv1;  //Create the Timeval structure tv1
	struct timeval tv2;  //Create the Timeval structure tv2
	long start, stop;
	float dis;

	digitalWrite(Trig, LOW);
	delayMicroseconds(2);

	digitalWrite(Trig, HIGH);
	delayMicroseconds(10);      	
    digitalWrite(Trig, LOW);
	
	while(!(digitalRead(Echo) == 1));  //Wait for the low level received by the Echo pin to pass
	gettimeofday(&tv1, NULL);   //function gettimeofday, The time it took the system to get here

	while(!(digitalRead(Echo) == 0));  //Wait for the high level received by the Echo pin to pass
	gettimeofday(&tv2, NULL);   //function gettimeofday, The time it took the system to get here
	    
    //Tv1.tv_sec is the seconds obtained, tv1.TV_USec is the subtlety obtained
    //Calculate the first time
	start = tv1.tv_sec * 1000000 + tv1.tv_usec;
	 
	//Calculate the second time
	stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;
    
    //stop - start , the time difference is the high level time acquired by the echo pin
    //34000cm/s, speed of sound
    //Calculate the distance measured(cm)
	dis = (float)(stop - start) / 1000000 * 34000 / 2;  

	return dis;
}

int main(void)
{
	float dis;

	if(wiringPiSetup() == -1){ //when initialize wiring failed,print messageto screen
		printf("setup wiringPi failed !");
		return 1; 
	}

	ultraInit();
	
	while(1){
		dis = disMeasure();
		printf("distance = %0.2f cm\n",dis);
		delay(100);
	}

	return 0;
}
