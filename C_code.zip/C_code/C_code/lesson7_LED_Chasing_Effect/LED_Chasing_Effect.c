#include <wiringPi.h>

#define led1 1 //BCM GPIO 18
#define led2 4 //BCM GPIO 23
#define led3 5 //BCM GPIO 24
#define led4 6 //BCM GPIO 25
#define led5 26 //BCM GPIO 12
#define led6 27 //BCM GPIO 16
#define led7 28 //BCM GPIO 20
#define led8 29 //BCM GPIO 21

int main()
{
    wiringPiSetup();
    pinMode(led1,OUTPUT);  //set pin OUTPUT mode
    pinMode(led2,OUTPUT);
    pinMode(led3,OUTPUT);
    pinMode(led4,OUTPUT);
    pinMode(led5,OUTPUT);
    pinMode(led6,OUTPUT);
    pinMode(led7,OUTPUT);
    pinMode(led8,OUTPUT);

    digitalWrite(led1, LOW);  //set pin LOW
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    digitalWrite(led4, LOW);
    digitalWrite(led5, LOW);
    digitalWrite(led6, LOW);
    digitalWrite(led7, LOW);
    digitalWrite(led8, LOW);
    
    while(1)
    {  
        //Light up one by one
        digitalWrite(led1, HIGH); 
        delay(200); 
        digitalWrite(led2, HIGH);
        delay(200); 
        digitalWrite(led3, HIGH);
        delay(200); 
        digitalWrite(led4, HIGH);
        delay(200);
        digitalWrite(led5, HIGH);
        delay(200); 
        digitalWrite(led6, HIGH);
        delay(200); 
        digitalWrite(led7, HIGH);
        delay(200); 
        digitalWrite(led8, HIGH);
        delay(200);
        
        //Turn off one by one
        digitalWrite(led1, LOW);
        delay(200); 
        digitalWrite(led2, LOW);
        delay(200); 
        digitalWrite(led3, LOW);
        delay(200); 
        digitalWrite(led4, LOW);
        delay(200);
        digitalWrite(led5, LOW);
        delay(200); 
        digitalWrite(led6, LOW);
        delay(200); 
        digitalWrite(led7, LOW);
        delay(200); 
        digitalWrite(led8, LOW);
        delay(200);
    }    
}
