#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>

#define PIR_pin 1  //PIR pin  BCM GPIO 18
#define led_pin 21  //LED pin BCM GPIO 5

int main(void)
{
   int val = 0;
   wiringPiSetup();
   pinMode(PIR_pin,INPUT);
   pinMode(led_pin,OUTPUT);
     
   while(1)
   {
      val=digitalRead(PIR_pin);
      if(val==1)
      {
         printf("somebody\n");
         digitalWrite(led_pin,HIGH);
      }
      else
      {
         printf("nobody\n");
         digitalWrite(led_pin,LOW);
      }
}
}
